const express = require("express");
const fs = require('fs');
const app = express();

app.get("/",(req,res)=>{
    fs.readFile('text.fsfile',(error,data)=>{
        console.log(data.toString('utf-8'));
        res.status(200).json({
            message : data.toString('utf-8'),})
        return
    })
});

app.get("/",(req,res)=>{
    fs.writeFile('text.fsfile','this is to write on fs file!',(error)=>{
        if (error) throw new Error(error);
    })
        res.status(200).json({
            message : 'Hello'})  
        });

app.put("/",(req,res)=>{
    fs.appendFile('text.fsfile','this line is to update in existing file.',(error)=>{
        if (error) throw new Error(error);
        console.log('this "abaove line" is to append in the file ')
    });
    res.status(200).json({
        message : 'update'})
    });

app.get("/",(req,res)=>{
    fs.unlink('text.fsfile',(error)=>{
        if (error) throw new Error(error)});
        res.status(200).json({
            message : 'Delete file'})
});



app.listen(3012,()=>{
    console.log("App started on port:", 3012);
    
});